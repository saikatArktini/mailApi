import { Module } from "@nestjs/common";
import { MailController } from "./mail.controller";
import { MailServices } from "./mail.services";

@Module({
  imports:[],
  controllers:[MailController],
  providers:[MailServices]
})
export class MailModule {}
