import { Injectable } from '@nestjs/common';
import * as nodemailer from 'nodemailer';
import { sendCommonMail } from './mail.template';


@Injectable()
export class MailServices {
  private transporter
  constructor() {
    this.transporter = nodemailer.createTransport({
      host: process.env.SERVICE_MAIL,
      port: parseInt(process.env.PORT),
      secure: true,
      auth: {
        user: process.env.EMAIL,
        pass: process.env.EMAIL_PASS_KEY
      },
      debug:true
    })
  }

  async sendMail(client:string, template:string,des:string,token:string) {
    try {
      const getMailTemp = sendCommonMail(client,template,des,token)
      if(getMailTemp===null){
        return {
          statusCode:401,
          message:"invalid client or template"
        }
      }
      const mail = await this.transporter.sendMail(getMailTemp)
      if(mail){
        return {
          statusCode:201,
          message:"mail sent"
        }
      }
      else{
        return {
          statusCode:401,
          message:"unable to send mail"
        }
      } 
    } catch (error) {
      return {
        statusCode:401,
        message: error.message
      }
    }
  }
}