import { NestFactory } from '@nestjs/core';
import { AppModule } from './app.module';
import * as dotenv from 'dotenv';
import { DocumentBuilder, SwaggerModule } from '@nestjs/swagger';

async function bootstrap() {
  dotenv.config();
  const app = await NestFactory.create(AppModule);
  const options = new DocumentBuilder()
    .setTitle("Mail Test")
    .setDescription("Mail api testing swagger")
    .setVersion('1.0')
    .addServer('http://localhost:3001/','Local environment')
    .addTag("Mail-Api")
    .build()
    const document = SwaggerModule.createDocument(app,options);
    SwaggerModule.setup('api-docs',app,document)
  await app.listen(3001);
}
bootstrap();
