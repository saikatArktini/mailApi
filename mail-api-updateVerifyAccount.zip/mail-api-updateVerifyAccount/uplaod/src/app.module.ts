import { Module } from '@nestjs/common';
import { AppController } from './app.controller';
import { AppService } from './app.service';
import { MailController } from './mail/mail.controller';
import { MailServices } from './mail/mail.services';
import { MailModule } from './mail/mail.module';

@Module({
  imports: [MailModule]
})
export class AppModule {}
