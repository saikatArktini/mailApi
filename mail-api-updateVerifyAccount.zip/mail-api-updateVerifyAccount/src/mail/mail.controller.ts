import { Controller, Post, Body } from '@nestjs/common';
import { MailServices } from './mail.services';
import { CreateMailDto } from './mail.dto';
import { templateMail } from './mail.template';
import { ApiBody, ApiResponse, ApiTags } from '@nestjs/swagger';

@ApiTags('Mail-Api')
@Controller('mail')
export class MailController {
  constructor(private readonly mailerService: MailServices) {}

  @Post('forgot')
  @ApiResponse({ status: 201, description: 'Email send succesfully' })
  @ApiResponse({ status: 401, description: 'Unable to send Email' })
  @ApiBody({
    type: CreateMailDto,
    description: 'Json structure to send forgot Mail',
  })
  async sendForgotEmail(@Body() createMailDto: CreateMailDto) {
    console.log("20",createMailDto);
    try {
      const mailSent = await this.mailerService.sendMail(
        createMailDto.client,
        'forgot',
        createMailDto.des,
        createMailDto.token,
      );
      console.log(mailSent);
      if (mailSent.statusCode === 201) {
        return {
          statusCode: 201,
          message: 'email send',
        };
      } else {
        return {
          statusCode: 401,
          message: mailSent.message,
        };
      }
    } catch (e) {
      return {
        statusCode: 401,
        message: e.message,
      };
    }
  }
  @Post('verify')
  @ApiResponse({ status: 201, description: 'Email send succesfully' })
  @ApiResponse({ status: 401, description: 'Unable to send Email' })
  @ApiBody({
    type: CreateMailDto,
    description: 'Json structure to send verification Mail',
  })
  async sendResetEmail(@Body() createMailDto: CreateMailDto) {
    try {
      const mailSent = await this.mailerService.sendMail(
        createMailDto.client,
        'signup',
        createMailDto.des,
        createMailDto.token,
      );
      console.log(mailSent);
      if (mailSent.statusCode === 201) {
        return {
          statusCode: 201,
          message: 'email send',
        };
      } else {
        return {
          statusCode: 401,
          message: mailSent.message,
        };
      }
    } catch (e) {
      return {
        statusCode: 401,
        message: e.message,
      };
    }
  }
}
