export const templateMail = {
  rj: {
    orgName: 'Ramasish Hindi High School',
    about:
      'Ramasish Hindi High School is Government sponsered Hindi 10+2 School',
    address: 'Mehendibagan, Burdwan, West Bengal 713101',
    signup: {
      title: 'Account Verification',
      subject: 'Account Verification',
      text: 'Verify you account using given link below',
      heading: 'Account Verification',
      paragraph:
        'Thanks for Joining Randonm Joy App. Here is the otp to verify your account',
      btnText: 'Verify Account',
      paragraph2: "If you didn't signUp, you can safely ignore this email",
      copyRight: '2025 Random Joy App. All rights reserved',
      url: 'https://ramashishindihighschool.org.in/verify',
    },
    forgot: {
      title: 'Ramasish Hindi High School - Reset Password Link',
      subject: 'Reset Password',
      text: 'Reset you password using given link below',
      heading: 'Reset Password',
      paragraph:
        'You requested password reset for Random Joy App. Here is the otp to reset your account password',
      btnText: 'Reset Password',
      paragraph2: "If you didn't request, you can safely ignore this email",
      copyRight: '2025 Random Joy App. All rights reserved',
      url: 'https://ramashishindihighschool.org.in/forgot',
    },
  },
  polopvc: {
    orgName: 'Polo Pvc Private Limited',
    about:
      'At Polo Pipes, we pride ourselves on delivering an extensive range of innovative and reliable plastic pipe solutions',
    address: 'Palitpur Road,Dewandighi Mirjapur,Purba Bardhaman- 713102',
    signup: {
      title: 'Polo Pvc Private Limited - Verification Link',
      subject: 'Account Verification',
      text: 'Verify you account using given link below',
      heading: 'Account Verification',
      paragraph:
        'Thanks for Joining PoloPvc Website. Click the button below to verify your account',
      btnText: 'Verify Account',
      paragraph2: "If you didn't signUp, you can safely ignore this email",
      copyRight: '2024 Polo Pvc Private Limited. All rights reserved',
      url: 'https://polopvc.com/verify',
    },
    forgot: {
      title: 'Polo Pvc Private Limited - Reset Password Link',
      subject: 'Reset Password',
      text: 'Reset you password using given link below',
      heading: 'Reset Password',
      paragraph:
        'You requested password reset for PoloPvc Website. Click the button below to reset you account password',
      btnText: 'Reset Password',
      paragraph2: "If you didn't request, you can safely ignore this email",
      copyRight: '2024 PoloPvc Website. All rights reserved',
      url: 'https://polopvc.com/forgot',
    },
  },
  pgm: {
    orgName: 'Prabhawti Global Marketing',
    about: 'Prabhawti Global Marketing',
    address: 'UP',
    signup: {
      title: 'Prabhawti Global Marketing - Verification Link',
      subject: 'Account Verification',
      text: 'Verify you account using given link below',
      heading: 'Account Verification',
      paragraph:
        'Thanks for Joining PGM. Click the button below to verify your account',
      btnText: 'Verify Account',
      paragraph2: "If you didn't signUp, you can safely ignore this email",
      copyRight: '2024 PGM. All rights reserved',
      url: 'https://localhost:3000/verify',
    },
    forgot: {
      title: 'Prabhawti Global Marketing - Reset Password Link',
      subject: 'Reset Password',
      text: 'Reset you password using given link below',
      heading: 'Reset Password',
      paragraph:
        'You requested password reset for PGM. Click the button below to reset you account password',
      btnText: 'Reset Password',
      paragraph2: "If you didn't request, you can safely ignore this email",
      copyRight: '2024 PGM. All rights reserved',
      url: 'http://localhost:3000/reset',
    },
  },
};
