import { ApiProperty } from "@nestjs/swagger";

export class CreateMailDto {
  @ApiProperty({
    example: "ramasish",
    required:true
  })
  readonly client: string;
  @ApiProperty({
    example:"jatan.bwn2003@gmail.com",
    required:true
  })
  readonly des: string;
  @ApiProperty({
    example:"edgdsjghaGHSF383237FUIFDSFS",
    required:true
  })
  readonly token: string;
}