import { Injectable } from '@nestjs/common';
import * as nodemailer from 'nodemailer';
import { templateMail } from './mail.template';

@Injectable()
export class MailServices {
  private transporter;
  constructor() {
    this.transporter = nodemailer.createTransport({
      host: 'pixel.mxrouting.net', //process.env.SERVICE_MAIL,
      port: 587, //parseInt(process.env.PORT),
      secure: false,
      auth: {
        user: 'support@randomjoy.app',   //process.env.EMAIL,
        pass: 'pD7N(#Ksu6ve&B' //process.env.EMAIL_PASS_KEY
      },
      debug: true,
    });
  }

  async sendMail(client: string, template: string, des: string, token: string) {
    //<a href="${templateMail[client][template].url}/${token}" class="btn">${templateMail[client][template].btnText}</a>
    try {
      console.log("23",client, template, des, token);
      const sub=template=="signup"?"Verify Account":"Password Reset";
      if (templateMail[client] === undefined) {
        return {
          statusCode: 401,
          message: 'invalid client',
        };
      }
      if (templateMail[client][template] === undefined) {
        return {
          statusCode: 401,
          message: 'invalid client',
        };
      }
      const mail = await this.transporter.sendMail({
        from: 'support@randomjoy.app',//process.env.EMAIL,
        to: des,
        subject: sub,
        text: templateMail[client][template].text,
        html: `<!DOCTYPE html>
        <html lang="en">
        <head>
            <meta charset="UTF-8">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <title>${templateMail[client][template].title}</title>
            <style>
                body {
                    font-family: 'Arial', sans-serif;
                    background-color: #f8f8f8;
                    margin: 0;
                    padding: 0;
                    text-align: center;
                }
                .container {
                    max-width: 600px;
                    margin: 50px auto;
                    background-color: #fff;
                    padding: 30px;
                    border-radius: 8px;
                    box-shadow: 0 0 20px rgba(0, 0, 0, 0.1);
                }
                h1 {
                    color: #e74c3c;
                    margin-bottom: 20px;
                }
                p {
                    color: #555;
                    margin-bottom: 20px;
                }
                .btn {
                    display: inline-block;
                    padding: 12px 24px;
                    background-color: #e74c3c;
                    color: #fff;
                    text-decoration: none;
                    border-radius: 5px;
                    transition: background-color 0.3s;
                }
                .btn:hover {
                    background-color: #c0392b;
                }
                .footer {
                    margin-top: 30px;
                    color: #888;
                    font-size: 12px;
                }
            </style>
        </head>
        <body>
            <div class="container">
                <h1>${templateMail[client][template].heading}</h1>
                <p>${templateMail[client][template].paragraph}</p>
                 <h1>${token}</h1>
                <p>${templateMail[client][template].paragraph2}.</p>
            </div>
            <div class="footer">
                <p>&copy; ${templateMail[client][template].copyRight}</p>
            </div>
        </body>
        </html>
        `,
      });
      if (mail) {
        return {
          statusCode: 201,
          message: 'mail sent',
        };
      } else {
        return {
          statusCode: 401,
          message: 'unable to send mail',
        };
      }
    } catch (error) {
      return {
        statusCode: 401,
        message: error.message,
      };
    }
  }
}
