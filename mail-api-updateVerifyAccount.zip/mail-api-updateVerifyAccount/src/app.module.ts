import { Module } from '@nestjs/common';
import { AppController } from './app.controller';
import { AppService } from './app.service';
import { MailController } from './mail/mail.controller';
import { MailServices } from './mail/mail.services';

@Module({
  imports: [],
  controllers: [AppController,MailController],
  providers: [MailServices,AppService],
})
export class AppModule {}
